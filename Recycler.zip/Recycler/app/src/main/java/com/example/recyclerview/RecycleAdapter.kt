package com.example.recyclerview

import android.graphics.Color.YELLOW
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecycleAdapter(
    private val exampleList: List<ExampleItem>,
    private val listener: OnItemClickListener) :
    RecyclerView.Adapter<RecycleAdapter.VHolder>() {
    // Called by Recycler viewer when it is time to create a new view holder
    // Returns the VHolder we created
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_example,
        parent, false)

        return VHolder(itemView)
    }

    // Will be called when scrolling and an item has to be filled with data
    // or when we update data
    override fun onBindViewHolder(holder: VHolder, position: Int) {
        val currentItem = exampleList[position]

        holder.imageView.setImageResource(currentItem.imageResource)
        holder.textView1.text = currentItem.text1
        holder.textView2.text = currentItem.text2
    }

    // Counting the items in the recycler view.
    // This will be the same amount as our example list
    override fun getItemCount() = exampleList.size

    inner class VHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
    View.OnClickListener {
        val imageView: ImageView = itemView.findViewById(R.id.image_view)
        val textView1: TextView = itemView.findViewById(R.id.text_view_1)
        val textView2: TextView = itemView.findViewById(R.id.text_view_2)

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val position = adapterPosition
            // Prevents issue when something has been deleted but the person clicks it
            // before the animation.
            if (position != RecyclerView.NO_POSITION){
                listener.onItemClick(position)
            }
        }
    }

    // Interface to pass click event to main activity
    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }
}