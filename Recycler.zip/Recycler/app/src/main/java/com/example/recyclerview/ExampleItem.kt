package com.example.recyclerview

// the item and the values it includes
data class ExampleItem(val imageResource: Int, var text1: String, var text2: String)