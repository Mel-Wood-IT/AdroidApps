package com.example.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.random.Random

class MainActivity : AppCompatActivity(), RecycleAdapter.OnItemClickListener {

    private val exampleList = generateDummyList(500)
    private val adapter = RecycleAdapter(exampleList, this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // His method did not work due to android removing a feature so findViewById has to be used
        findViewById<RecyclerView>(R.id.recycler_view).adapter = adapter
        findViewById<RecyclerView>(R.id.recycler_view).layoutManager = LinearLayoutManager(this)
        findViewById<RecyclerView>(R.id.recycler_view).setHasFixedSize(true)

        // Another method to do the same thing
        //findViewById<RecyclerView>(R.id.recycler_view).apply {
        //    adapter = RecycleAdapter(exampleList)
        //   layoutManager = LinearLayoutManager(context)
        //    setHasFixedSize(true)
        //}
    }

    fun insertItem(view: View) {
        val index = Random.nextInt(8)

        val newItem = ExampleItem(
            R.drawable.baseline_download,
            "New item at position $index",
            "Line 2"
        )

        exampleList.add(index, newItem)
        adapter.notifyItemInserted(index)

        // Do not use, not efficient
        //adapter.notifyDataSetChanged()
    }
    fun removeItem(view: View) {
        val index = Random.nextInt(8)

        exampleList.removeAt(index)
        adapter.notifyItemRemoved(index)
    }

    override fun onItemClick(position: Int) {
        Toast.makeText(this,"Item $position clicked", Toast.LENGTH_SHORT).show()
        val clickedItem : ExampleItem = exampleList[position]
        clickedItem.text1 = "Clicked"
        adapter.notifyItemChanged(position)
    }

    // Algorithm to generate data for the example list
    // Will create a list of example items
    private fun generateDummyList(size: Int) : ArrayList<ExampleItem> {

        // New empty array list
        val list = ArrayList<ExampleItem>()

        // Use size in for loop to alternate between the three chosen images
        for (i in 0 until size) {
            val drawable = when (i % 3) {
                0 -> R.drawable.ic_android
                1 -> R.drawable.baseline_chat
                else -> R.drawable.baseline_download
            }
            // New example item is created by calling constructor and
            // passing the three arguments to it
            val item = ExampleItem(drawable, "Item $i", "Line 2")
            list += item
        }
        return list
    }

}