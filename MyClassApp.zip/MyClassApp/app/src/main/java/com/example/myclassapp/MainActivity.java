package com.example.myclassapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

// Set up main screen with buttons to add and minus from a number
// and a button to access a second screen

public class MainActivity extends AppCompatActivity {
    // Passing variable to next screen
    // Set a reference name so the variable can be found in the other class.
    public static final String RESULT_TEXT = "com.example.myclassapp.RESULT_TEXT";


    // Create the objects for buttons
    Button AddButton;
    TextView ResultTV;
    Button MinusButton;
    Button NextScreenButton;

    int num=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Links to the layout
        setContentView(R.layout.activity_main);

        // register variables with XML id references
        // Register the buttons to the button created in the xml
        AddButton = (Button)findViewById(R.id.my_btn_add);
        MinusButton = (Button) findViewById(R.id.my_btn_minus);
        ResultTV = (TextView) findViewById(R.id.my_total);
        NextScreenButton = findViewById(R.id.my_btn_nextscreen);


        // Create the event for clicking the button (what happens when clicked)
        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num++;
                ResultTV.setText(String.valueOf(num));
            }
        });

        // Create the event for clicking the button (what happens when clicked)
        MinusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num--;
                ResultTV.setText(String.valueOf(num));
            }
        });

        // Button being activated
        NextScreenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onNextScreenClick(v);
            }
        });
    }

    public void onNextScreenClick(View v){
        // grab text out of text view
        String result = ResultTV.getText().toString();

        // Screens are Activities and Intents
        Intent i = new Intent(this, NextScreenActivity.class);
        // Passing the result
        i.putExtra(RESULT_TEXT, result);
        startActivity(i);
    }
}