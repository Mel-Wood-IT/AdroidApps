package com.example.myclassapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class NextScreenActivity extends AppCompatActivity {

    TextView tvFinal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Loads next screen
        setContentView(R.layout.activity_next_screen);

        tvFinal = (TextView) findViewById(R.id.tv_final);

        Intent intent = getIntent();
        // Pull data from main
        String text = intent.getStringExtra(MainActivity.RESULT_TEXT);

        tvFinal.setText("The final is: " + text);
    }
}